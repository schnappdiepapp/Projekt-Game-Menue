package com.example.projektsylvia_wahls;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

/**
 * MainActivity:
 * Hauptmenü
 * Buttons werden verknüpft (XML und Java)
 * Über die Buttons kann man den View wechseln
 *
 * @author Sylvia Wahls
 */

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button startGameButton;
    private Button highscoreButton;
    private Button aboutGameButton;
    private Button settingButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainview);

        startGameButton = findViewById(R.id.startgamebutton);
        highscoreButton = findViewById(R.id.highscoresButtonID);
        aboutGameButton = findViewById(R.id.aboutgameButtonID);
        settingButton = findViewById(R.id.settingsBtnID);

        startGameButton.setOnClickListener(this);
        highscoreButton.setOnClickListener(this);
        aboutGameButton.setOnClickListener(this);
        settingButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v){

        Intent intent = null;


        if(startGameButton.getId() == v.getId()){
            intent = new Intent(MainActivity.this,GameStartActivity.class);
        }
        if(highscoreButton.getId() == v.getId()){
            intent = new Intent(MainActivity.this, HighscoreActivity.class);
        }
        if(aboutGameButton.getId() == v.getId()){
            intent = new Intent(MainActivity.this, AboutGameActivity.class);
        }
        if(settingButton.getId() == v.getId()){
            intent = new Intent(MainActivity.this, SettingsActivity.class);
        }
        if(intent != null){
            startActivity(intent);
        }
    }

}