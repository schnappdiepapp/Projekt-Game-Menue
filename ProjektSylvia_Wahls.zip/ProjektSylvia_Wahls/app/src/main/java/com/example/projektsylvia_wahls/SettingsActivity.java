package com.example.projektsylvia_wahls;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * SettingsActivity:
 * Benutzername kann überschrieben und in globaler Variable abgespeichert werden
 *
 * @author Sylvia Wahls
 */

public class SettingsActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText benutzerNameTV;
    private Button absenden;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.settingsview);

        benutzerNameTV = findViewById(R.id.neuerNameID);

        absenden = findViewById(R.id.settingsButtonID);


        absenden.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String benutzerName = benutzerNameTV.getText().toString();
        Intent intent = null;


        if(absenden.getId() == v.getId()){
            SharedPreferences sp = getSharedPreferences("com.example.projektsylvia_wahls", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("Benutzername", benutzerName);
            editor.apply();
            Toast.makeText(this, benutzerName, Toast.LENGTH_LONG).show();
            intent = new Intent(this, MainActivity.class);
        }
        if(intent != null){
            startActivity(intent);
        }
    }

}
