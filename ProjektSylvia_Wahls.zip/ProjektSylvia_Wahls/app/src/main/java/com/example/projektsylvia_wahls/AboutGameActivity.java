package com.example.projektsylvia_wahls;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * AboutGameActivity:
 * Der Login-Name wird zentriert angezeigt
 *
 * @author Sylvia Wahls
 */

public class AboutGameActivity extends AppCompatActivity {


    private TextView benutzerNameTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aboutgameview);

        //übergabe des Benutzernamens an das TextView
        SharedPreferences sp = getSharedPreferences("com.example.projektsylvia_wahls", MODE_PRIVATE);

        benutzerNameTV = findViewById(R.id.aboutNameID);
        String name = sp.getString("Benutzername", "");
        benutzerNameTV.setText(name);

    }
}
