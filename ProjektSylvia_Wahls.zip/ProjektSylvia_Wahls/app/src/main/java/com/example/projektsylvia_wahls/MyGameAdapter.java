package com.example.projektsylvia_wahls;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * MyGameAdapter:
 * Bindeglied zwischen Datenquelle(HighscoreListItem) und View-Element(highscoreview)
 *
 * @author Sylvia Wahls
 */

public class MyGameAdapter extends RecyclerView.Adapter<MyGameAdapter.GameViewHolder>{
    private ArrayList<HighscoreListItem> mainList;

    public MyGameAdapter(ArrayList<HighscoreListItem> mainList) {
        this.mainList = mainList;

    }


    @NonNull
    @Override
    public MyGameAdapter.GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem_layout,parent, false);
        GameViewHolder gameViewHolder = new GameViewHolder(v);
        return gameViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyGameAdapter.GameViewHolder holder, int position) {
        HighscoreListItem listItem = mainList.get(position);
        holder.nameTV.setText("" + listItem.getName());
        holder.levelTV.setText("" + listItem.getLevel());
        holder.punkteTV.setText("" + listItem.getPunkte());
    }



    @Override
    public int getItemCount() {
        return mainList.size();
    }

    public class GameViewHolder extends RecyclerView.ViewHolder {

        public TextView nameTV,levelTV,punkteTV;

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);

            this.nameTV = itemView.findViewById(R.id.name_tv);
            this.levelTV = itemView.findViewById(R.id.level_tv);
            this.punkteTV = itemView.findViewById(R.id.punkte_tv);
        }
    }
}
