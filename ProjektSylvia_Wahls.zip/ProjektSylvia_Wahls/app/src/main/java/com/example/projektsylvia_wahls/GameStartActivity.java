package com.example.projektsylvia_wahls;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * GameStartActivity:
 * Der Text „Coming soon ...“ wird zentriert angezeigt.
 *
 * @author Sylvia Wahls
 */

public class GameStartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gamestartview);
    }
}
