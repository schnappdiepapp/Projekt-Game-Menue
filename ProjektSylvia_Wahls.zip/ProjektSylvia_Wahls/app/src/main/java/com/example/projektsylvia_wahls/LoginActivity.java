package com.example.projektsylvia_wahls;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity:
 * Logindaten (Name und Passwort) müssen eingegeben werden
 * Diese werden überprüft
 * Nach erfolgreichem Einloggen, wird und bleibt man angemeldet
 * Falscheingaben werden erkannt
 *
 * @author Sylvia Wahls
 */
public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private SharedPreferences sp;
    private Button loginButton;
    private EditText loginNameTV;
    private EditText passwortTV;
    private String benutzerName = "Sylvsche";
    private final String passwort = "1234";
    private boolean login = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginview);

        loginButton = findViewById(R.id.loginbuttonID);
        loginButton.setOnClickListener(this);

        loginNameTV = findViewById(R.id.loginnameID);
        passwortTV = findViewById(R.id.passwortID);

        sp = getSharedPreferences("com.example.projektsylvia_wahls", MODE_PRIVATE);
        login = sp.getBoolean("ueberpruefeLogin",false);


        // Wenn erfolgreiche Anmeldung stattfand, wird neue Anmeldung übersprungen
        if (login) {
            startActivity(new Intent(this, MainActivity.class));
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        String name = loginNameTV.getText().toString();
        String pwd = passwortTV.getText().toString();
        sp = getSharedPreferences("com.example.projektsylvia_wahls", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        // Wenn ein Eingabefeld (Name oder Passwort) nicht ausgefüllt wurde,
        // wird es angezeigt:
        if (name.equals("") || pwd.equals("")) {
            Toast.makeText(this, "Bitte Name UND Passwort eingeben!", Toast.LENGTH_LONG).show();
        }


        // Benutzername wird in einer globalen Variable abgespeichert
        if (loginButton.getId() == v.getId()) {
            if (pwd.equals(passwort) && name.equals(benutzerName)) {
                editor.putString("Benutzername", benutzerName);
                editor.putBoolean("ueberpruefeLogin", true).apply();
                intent = new Intent(this, MainActivity.class);
                Toast.makeText(this, name, Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this, "Benutzername oder Passwort falsch!", Toast.LENGTH_LONG).show();
                editor.putBoolean("ueberpruefeLogin", false);
            }
        }
        if (intent != null) {
            startActivity(intent);
        }
    }
}
