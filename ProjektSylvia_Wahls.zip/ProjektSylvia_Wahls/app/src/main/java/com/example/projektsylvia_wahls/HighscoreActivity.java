package com.example.projektsylvia_wahls;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * HighscoreActivity:
 * Liste mit den 10 besten Spielern wird angezeigt
 * Man kommt ebenfalls in den GameStartView
 *
 * @author Sylvia Wahls
 */

public class HighscoreActivity extends AppCompatActivity implements View.OnClickListener {

    private Button highscoreButton;
    private RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.highscoresview);

        highscoreButton = findViewById(R.id.highscoreStartButtonID);
        highscoreButton.setOnClickListener(this);

        ArrayList<HighscoreListItem> highscoreList = createArrayList();

        MyGameAdapter highscoreListAdapter = new MyGameAdapter(highscoreList);
        rv = findViewById(R.id.mainRVID);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);

        rv.setLayoutManager(layoutManager);
        rv.setAdapter(highscoreListAdapter);

    }

    private ArrayList<HighscoreListItem> createArrayList() {
        ArrayList<HighscoreListItem> highscoreList = new ArrayList<>();

        SharedPreferences sp = getSharedPreferences("com.example.projektsylvia_wahls", MODE_PRIVATE);

        highscoreList.add(new HighscoreListItem("1. "+ sp.getString("Benutzername", ""), 1, 43));
        highscoreList.add(new HighscoreListItem("2. A", 2, 100));
        highscoreList.add(new HighscoreListItem("3. Be", 3, 235));
        highscoreList.add(new HighscoreListItem("4. Ce", 5, 398));
        highscoreList.add(new HighscoreListItem("5. De", 47, 432));
        highscoreList.add(new HighscoreListItem("6. E", 55, 544));
        highscoreList.add(new HighscoreListItem("7. Ef", 71, 645));
        highscoreList.add(new HighscoreListItem("8. Ge", 85, 773));
        highscoreList.add(new HighscoreListItem("9. Ha", 224, 896));
        highscoreList.add(new HighscoreListItem("10. Ieh", 2652, 991));

        return highscoreList;
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        if(highscoreButton.getId() == v.getId()){
            intent = new Intent(this, GameStartActivity.class);
        }
        if(intent != null){
            startActivity(intent);
        }
    }

}
