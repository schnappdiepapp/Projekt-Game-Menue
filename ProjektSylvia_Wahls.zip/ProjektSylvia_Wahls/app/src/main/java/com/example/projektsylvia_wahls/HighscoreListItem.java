package com.example.projektsylvia_wahls;

/**
 * HighscoreListItem:
 * Variablen, Konstruktor, Getter und Setter für die Highscore-Liste
 *
 * @author  Sylvia Wahls
 */

public class HighscoreListItem {

    private String name;
    private int level, punkte;

    public HighscoreListItem(String name, int level, int punkte){

        this.name = name;
        this.level = level;
        this.punkte = punkte;

    }

    public int getLevel() {
        return level;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPunkte() {
        return punkte;
    }


}
